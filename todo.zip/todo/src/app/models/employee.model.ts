export class Employee{
    public id: number = 0;
    public Assigned_by: string = '';
    public ToDo: string= '';
    

}