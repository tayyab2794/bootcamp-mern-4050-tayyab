import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees: Employee[] = [
    {
      id: 1,
      Assigned_by: "ali",
      ToDo: "complete the task",
     
    },
    {
      id: 2,
      Assigned_by: "akram",
      ToDo: "complete the 2nd task",
      
    },
  ];
  constructor() { }

  onGet(){
    return this.employees;
  }
  onGetEmployee(id: Number){
    return this.employees.find(x=>x.id === id);
  }
  onAdd(employee: Employee){
    this.employees.push(employee);
  }
  onDelete(id: Number){
    let employee = this.employees.find(x=>x.id === id);
    let index = this.employees.indexOf(employee,0);
    this.employees.splice(index,1);
  }
  onUpdate(employee: Employee){
    let oldEmployee = this.employees.find(x=>x.id === employee.id);
    oldEmployee.Assigned_by = employee.Assigned_by;
    oldEmployee.ToDo = employee.ToDo;
    
  }
}
